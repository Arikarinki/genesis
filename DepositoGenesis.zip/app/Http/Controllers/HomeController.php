<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use DB;
use Dompdf\Dompdf;
use App\Productos;
use App\Servicios;
use App\Proveedores;
use App\Categorias;
use App\Marcas;

class HomeController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('auth');
    }

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Contracts\Support\Renderable
     */
    public function index()
    {
        return view('home');
    }



    public function reporte()
    {
        $ventas = DB::table('ventas')
            ->join('users', 'users.id', '=', 'ventas.id_users')
            ->join(
                'productos',
                'productos.id',
                '=',
                'ventas.id_productos'
            )
            ->join(
                'proveedores',
                'proveedores.id',
                '=',
                'ventas.id_proveedores'
            )
            ->select(
                'users.id',
                'name',
                'descripcion',
                'precio',
                'nombre',
                'direccion',
                'numero'
            )
            ->get();
        $view = \View::make('ventas.ventas', compact('ventas'))->render();
        //devuelve el contenido ala vista
        $pdf = \App::make('dompdf.wrapper'); //llamando localmete el generador pdf
        $pdf->loadHTML($view); //lectura modo pdf
        return $pdf->stream('informe' . '.pdf'); //retornar en modo vista
        // return view('ventas.ventas', compact('ventas'));

        // dd($ventas);
    }
   public function ventaindex()
    {

       // $productos = Productos::select('id')->take(1)
      //  ->orderby('created_at', 'DESC')->get();
       // $view = \View::make('ventas.llenarreporte', compact('productos'))->render();
      //  return view('ventas.llenarreporte', compact('productos'));
        //////////////////////////
        $proveedores = Proveedores::select('id')//->take(1)
        ->orderby('created_at', 'DESC')->get();
        $view = \View::make('ventas.llenarreporte', compact('proveedores'))->render();
        return view('ventas.llenarreporte', compact('proveedores'));
    }
    /////////////////////
    public function ventaindex1()
    {


        $proveedores = Proveedores::select('id')->take(1)
            ->orderby('created_at', 'DESC')->get();

        $view = \View::make('ventas.llenarreporte', compact('proveedores'))->render();

        return view('ventas.llenarreporte', compact('proveedores'));
    }
    public function ventacompra()
    {

        // dd($ventas);
        $view = \View::make('ventas.ventareporte');
        //return view('ventas.ventareporte', compact('ventas'));
        $pdf = \App::make('dompdf.wrapper'); //llamando localmete el generador pdf
        $pdf->loadHTML($view); //lectura modo pdf
        return $pdf->stream('informe' . '.pdf'); //retornar en modo vista
    }


    ///consulta
    public function servicio()
    {
            $servicio= Servicios::all();
            return view('negocios.servicios',compact('servicio'));
       //dd($servicio);
    }
    public function categoria()
    {
            $categorias= Categorias::all();
            return view('negocios.categorias',compact('categorias'));
       //dd($categorias);
    }
    public function marcas()
    {
            $marcas= Marcas::all();
           return view('negocios.marcas',compact('marcas'));
       //dd($marcas);
    }
}
