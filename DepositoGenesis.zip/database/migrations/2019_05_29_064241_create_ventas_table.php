<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateVentasTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('ventas', function (Blueprint $table) {
            //$table->bigIncrements('id');
            $table->engine = 'InnoDB';
            $table->bigIncrements('id_ventas');
            $table->bigInteger('id_productos')-> nullable(false)->unsigned();
            $table->bigInteger('id_users')-> nullable(false) ->unsigned();
            $table->bigInteger('id_proveedores')->unsigned();
            //relacion
            //tabla productos
            $table->foreign('id_productos')->references('id')->on('productos')
            ->onDelete('cascade')
            ->onUpdate('cascade');
            //tabla usuarios
            $table->foreign('id_users')->references('id')->on('users')
            ->onDelete('cascade')
            ->onUpdate('cascade');
            //tabla proveedores
            $table->foreign('id_proveedores')->references('id')->on('proveedores')
            ->onDelete('cascade')
            ->onUpdate('cascade');
            

            $table->timestamps();
            
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('ventas');
    }
}
