const myapp = new Vue({

    el:'#myapp', 
    data:{
        titulo:'Hello mundo desde VueJS',
        at_codigoBarras:'',
        at_descripcion:'',
        at_precio:'',
        pestanias:['Inicio','Contactanos','Acerca de..','Ayuda'],
        productos: [
            {
                codigoBarras:'10001',
                descripcion: 'Coca-Cola Lata 355ml',
                precio: 13,
                stock: 48
            },
            {
                codigoBarras:'10002',
                descripcion: 'Sabritas 120gr',
                precio: 12,
                stock: 48
            },
            {
                codigoBarras:'10003',
                descripcion: 'Gansito Marinela',
                precio: 10,
                stock: 0
            }
        ]

    },
    methods:{
        agregarProducto: function(){
            this.productos.push({
                codigoBarras:this.at_codigoBarras,
                descripcion: this.at_descripcion,
                precio: this.at_precio,
                stock: this.at_stock 

            })
        }
    }
})