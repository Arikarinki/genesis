<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta http-equiv="X-UA-Compatible" content="ie=edge">
  <link rel="stylesheet" href="css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
  <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
  <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.6.3/css/all.css" integrity="sha384-UHRtZLI+pbxtHCWp1t77Bi1L4ZtiqrqD80Kn4Z8NTSRyMA2Fd33n5dQ8lWUE00s/" crossorigin="anonymous">
</head>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.0/jquery.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>


<title>Curso laravel</title>
<style>
  .fondo {
    background-image: url(img/dental6.jpg);
  }
  .footer {
    background: white;
    color: white;
  }

</style>

</head>
<nav class="navbar navbar-expand-sm navbar-dark bg-dark">
<h4 class="h"><img class="imagen" width="80" heigth="50" src="img/logoP.png"></h4>
  <div class="card-footer">
    <a class="font-weight-bold">Bienvenido </a> {{ auth()->user()->name }}
    <i class="fas fa-user"></i>
  </div>
  <button class="navbar-toggler d-lg-none" type="button" data-toggle="collapse" data-target="#collapsibleNavId" aria-controls="collapsibleNavId" aria-expanded="false" aria-label="Toggle navigation"></button>
  <div class="collapse navbar-collapse" id="collapsibleNavId">
    <ul class="navbar-nav mr-auto mt-2 mt-lg-0">
      <li class="nav-item active">
        <a class="nav-link" href="{{route('productos.create')}}">Producto <span class="sr-only">(current)</span></a>
      </li>
      <li class="nav-item active">
        <a class="nav-link" href="{{route('proveedor.indexProveedor')}}">Proveedores <span class="sr-only">(current)</span></a>
      </li>
      <li class="nav-item active">
        <a class="nav-link" href="{{route('service.servicios')}}">Servicios <span class="sr-only">(current)</span></a>
      </li>
      <li class="nav-item active">
        <a class="nav-link" href="{{route('categorias.categorias')}}">Categorias <span class="sr-only">(current)</span></a>
      </li>
      <li class="nav-item active">
        <a class="nav-link" href="{{route('marcass.marcass')}}">Marcas <span class="sr-only">(current)</span></a>
      </li>
    </ul>
    <a href="javascript:document.getElementById('logout').submit()" class="btn btn-danger float-right">Cerrar sesión</a>
    <form action="{{ route('logout') }}" id="logout" style="display:none" method="POST">
      @csrf

    </form>
  </div>
</nav>
<br>

<body class='fondo'>
  @yield('contenido')

  <br>
  <br>
  <br>
  <br>
  <br>
  <br>
  <div class="footer">
    <div class="card bg-dark">
      <div class="card-body">
        <p class="card-text"><i class="fas fa-copyright"> Copyright Derechos Reservados</i></p>
      </div>
    </div>
  </div>
  </div>
</body>
</html>
