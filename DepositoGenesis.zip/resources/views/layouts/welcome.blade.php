<!doctype html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">

<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">

  <title>Laravel</title>

  <!-- Fonts -->

  <link rel="stylesheet" href="css/bootstrap.min.css">
  <link rel="stylesheet" href="js/bootstrap.min.js">
  <link rel="stylesheet" href="js/popper.min.js">
  <link rel="stylesheet" href="js/jquery-3.3.1.slim.min.js">
  <link rel="stylesheet" href="js/jquery.js">



  <style>
    .fondo {
      background-image: url(img/fondo5.jpg);
    }

    .footer {
      background: black;
      color: white;
    }

    a,
    i {
      background: black;
      color: white;
    }
  </style>

</head>

<body class='fondo'>
  <nav class="navbar navbar-expand-sm navbar-dark bg-dark">

    <button class="navbar-toggler d-lg-none" type="button" data-toggle="collapse" data-target="#collapsibleNavId" aria-controls="collapsibleNavId" aria-expanded="false" aria-label="Toggle navigation"></button>
    <div class="collapse navbar-collapse" id="collapsibleNavId">
      <ul class="navbar-nav mr-auto mt-2 mt-lg-0">
      <li role="presentation" ><a href="" class="a"><h4 class="h"><img class="imagen" width="120" heigth="10000" src="img/icono.jpg"></h4></a></li>


        <li class="nav-item active">
          //<a class="nav-link" href="{{ route('vistas.inicio2') }}">Quienes somos? <span class="sr-only">(current)</span></a>
        </li>
        <li class="nav-item active">
          <a class="nav-link" href="#">Acerca <span class="sr-only">(current)</span></a>
        </li>
        <li class="nav-item active">
         //<a class="nav-link" href="#">Trabaja con Nosotros <span class="sr-only">(current)</span></a>
        </li>
        <li class="nav-item active">
          //<a class="nav-link" href="{{ route('vistas.inicio1') }}">Nuesta Visión y Misión <span class="sr-only">(current)</span></a>
        </li>

      </ul>
      <form class="form-inline my-2 my-lg-0">
        <a class="navbar-brand" href="{{ route('login') }}" class="btn btn-outline-primary"> Iniciar Sesión </a>
        <a class="navbar-brand" href="{{ route('register') }}" class="btn btn-outline-primary">Registrar </a>

      </form>
    </div>
  </nav>
  <div class="container">

    <nav>

    </nav>
    <div id="switcher">
      <div class="center">
        <div class="responsive">
          <div class="flex-center position-ref full-height">
            @if (Route::has('login'))
            <div class="top-right links">
              @auth
              <a href="{{ url('/inicio') }}">Inicio</button>
                @else


                @if (Route::has('register'))

                @endif
                @endauth
            </div>
            @endif
          </div>
        </div>
      </div>
    </div>


    <div id="carouselExampleControls" class="carousel slide" data-ride="carousel">
      <div class="carousel-inner">
        <div class="carousel-item active">
          <img src="img/acceso.jpg" class="d-block w-100" alt="...">
        </div>
        <div class="carousel-item">
          <img src="img/alarmas.jpg" class="d-block w-100" alt="...">

        </div>
        <div class="carousel-item">
          <img src="img/cctv.jpg" class="d-block w-100" alt="...">
        </div>
        <div class="carousel-item">
          <img src="img/epcom.jpg" class="d-block w-100" alt="...">
        </div>
      </div>
      <a class="carousel-control-prev" href="#carouselExampleControls" role="button" data-slide="prev">
        <span class="carousel-control-prev-icon" aria-hidden="true"></span>
        <span class="sr-only">Previous</span>
      </a>
      <a class="carousel-control-next" href="#carouselExampleControls" role="button" data-slide="next">
        <span class="carousel-control-next-icon" aria-hidden="true"></span>
        <span class="sr-only">Next</span>
      </a>
    </div>
  </div>
  <br>
  <div class="footer">
    <div class="card bg-dark">
      <div class="card-body">

      </div>
    </div>
  </div>




  <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>
  <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>

</body>

</html>
