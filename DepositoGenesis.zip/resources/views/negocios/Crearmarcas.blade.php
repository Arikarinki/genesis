@extends('layouts.main')
@section('contenido')
<style>
    html,
    body {
        background-color: #2A2A2E;
        color: #636b6f;
        font-family: 'Nunito', sans-serif;
        font-weight: 2100;
        height: 100vh;
        margin: 10;
    }
</style>
<div class="container">
    <div class="row">
        <div class="col-md-12">
            <div class="card">
                <!-- muestra un listado de columnas de forma de tarjetas-->
                <div class="card-header">
                   Ingresar Marca
                </div>
                <div class="card-body">
                    <form action="{{route('productos.guardarmarcas')}}" method="POST">
                        @csrf
                        <div class="form-group>">
                            <label for="">Nombre</label>
                            <input type="text" class="form-control" name="nombre">
                        </div><br>
                        <button type="submit" class="btn btn-primary">Guardar</button>
                        <a href="{{route('marcass.marcass')}}" class="btn btn-danger">Cancelar</a>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection
