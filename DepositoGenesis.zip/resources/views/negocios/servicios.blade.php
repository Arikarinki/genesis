@extends('layouts.main')
@section('contenido')
<style>
    html,
    body {
        background-color: #2A2A2E;
        color: #636b6f;
        font-family: 'Nunito', sans-serif;
        font-weight: 2100;
        height: 100vh;
        margin: 10;
    }
</style>
<div class="container"><br>

    <div class="row">
        <div class="col-md-12">
            <div class="card">
                <!-- muestra un listado de columnas de forma de tarjetas-->
                <div class="card-header">
                    <a href="{{ route('inicio.name')}}" class="btn btn-warning btn-sm float-right">Regresar</a>
                    Servicios
                    <a href="{{ route('crateS.crear')}}" class="btn btn-success btn-sm float-right">Agregar Servicio</a>
                </div>
                <div class="card-body">
                    @if(session('info'))
                    <div class="alert alert-success">
                        {{session('info')}}
                        @endif
                    </div>
                    <table class="table table-hover table-sm">
                        <thead>
                            <tr>
                                <th>ID</th>
                                <th>SERVICIOS</th>
                            </tr>
                        </thead>
                        <tbody>
                        @foreach ($servicio AS $s)
                            <tr>
                                <td>
                                    {{$s->id}}
                                </td>
                                <td>
                                    {{$s->nombre}}
                                </td>
                                <td>
                                    <!--
                                    <a href="" method="POST" class="btn btn-danger btn-sm">Eliminar</a>
                                    <a><i class="fa fa-trash"></i></a>
                                    <a href="" class="btn btn-outline-success btn-sm">Consultar</a>
                                    <a href="" class="btn btn-primary btn-sm">Imprimir</a>-->
                                </td>
                            </tr>
                            @endforeach
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>
</div>
@endsection
