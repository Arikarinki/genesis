@extends('layouts.main')
@section('contenido')
<style>
    html,
    body {
        background-color: #2A2A2E;
        color: #636b6f;
        font-family: 'Nunito', sans-serif;
        font-weight: 2100;
        height: 100vh;
        margin: 10;
    }

</style>

<div class="container">
    <div class="row">
        <div class="col-md-12">
            <div class="card">
                <!-- muestra un listado de columnas de forma de tarjetas-->
                <div class="card-header">
                    Ingresar Producto
                </div>
                <div class="card-body">
                    <form action="{{route('productos.guardar')}}" method="POST">
                        @csrf
                        <div class="form-group">
                            <label for="">Producto</label>
                        </div>
                        <div class="form-group">
                            <input type="text" class="form-control" name="descripcion">
                        </div>
                        <div class="form-group">
                            <label for="">Precio</label>
                        </div>
                        <div class="input-group mb-3">
                            <div class="input-group-prepend">
                                <span class="input-group-text">$</span>
                            </div>
                            <input type="text" name="precio" value="" maxlength="9" onKeypress="if (event.keyCode < 45 || event.keyCode > 57) event.returnValue = false;" class="form-control" aria-label="Amount (to the nearest dollar)">
                        </div>
                        <button type="submit" class="btn btn-primary">Guardar</button>
                        <a href="{{route('inicio.name')}}" class="btn btn-danger">Cancelar</a>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection
