@extends('layouts.main')
@section('contenido')
<div class="container"><br>
    <div class="row">
        <div class="col-md-12">
            <div class="card"><!-- muestra un listado de columnas de forma de tarjetas-->
                <div class="card-header">
                    Editar Producto
                    </div>
                    <div class="card-body">
                            <form action="{{ route('productos.update',$product->id)}}" method="POST">
                                @method('put')
                            @csrf
                                <div class="form-group>">
                                <label for="">Descripción</label>
                              <input type="text" name="descripcion" value="{{ $product->descripcion }}" class="form-control">
                            </div>
                            <div class="form-group">
                                <label for="">Precio</label>
                              <input type="number"  name="precio" value="{{ $product->precio }}" class="form-control">
                          </div>
                          <button type="submit" class="btn btn-outline-success">Guardar</button>
                          <a href="{{ route('inicio.name') }}" class="btn btn-danger">Cancelar</a>
                          </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
@endsection
