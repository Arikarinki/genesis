@extends('layouts.main')
@section('contenido')
<style>
    html,
    body {
        background-image: <source><img src="fondo1"alt="">;
        color: whitesmoke;
        font-family: 'Nunito', sans-serif;
        font-weight: 2100;
        height: 100vh;
        margin: 10;
    }

    p {
        color: black;
        font-family: 'Nunito', sans-serif;
        margin: 10;
    }

    html,
    body,
    header,
    #intro {
        height: 100%;
    }



    body {}
</style>

<div class="container"><br>
    <div id="intro" class="view">
        <div class="full-bg-img">
        </div>
    </div>

    <div class="row">
        <div class="col-md-12">
            <div class="card">
                <!-- muestra un listado de columnas de forma de tarjetas-->
                <div class="card-header">
                    <p class="font-weight-bold">Productos</p>
                    <p><i class="fa fa-folder-open"></i></p>
                </div>
                <div class="container">
                    <nav class="navbar navbar-expand-sm navbar-dark bg-dark">
                        <!-- <a class="navbar-brand" href="{{route('ventas.guardar')}}">Llenar reporte por producto</a>
                        <i class="fas fa-print"></i>
                        <button class="navbar-toggler d-lg-none" type="button" data-toggle="collapse" data-target="#collapsibleNavId" aria-controls="collapsibleNavId" aria-expanded="false" aria-label="Toggle navigation"></button>
                        <div class="collapse navbar-collapse" id="collapsibleNavId">
                            <ul class="navbar-nav mr-auto mt-2 mt-lg-0"></ul>
                        </div>
                        <button class="navbar-toggler d-lg-none" type="button" data-toggle="collapse" data-target="#collapsibleNavId" aria-controls="collapsibleNavId" aria-expanded="false" aria-label="Toggle navigation"></button>
                        <div class="collapse navbar-collapse" id="collapsibleNavId">
                            <ul class="navbar-nav mr-auto mt-2 mt-lg-0"></ul>
                        </div>
                        <a class="navbar-brand" href="{{route('ventas.reporte')}}">Reporte</a>
                        <i class="fas fa-print"></i>
                        <button class="navbar-toggler d-lg-none" type="button" data-toggle="collapse" data-target="#collapsibleNavId" aria-controls="collapsibleNavId" aria-expanded="false" aria-label="Toggle navigation"></button>
                        <div class="collapse navbar-collapse" id="collapsibleNavId">
                            <ul class="navbar-nav mr-auto mt-2 mt-lg-0"></ul>
                        </div>
                        <a class="navbar-brand" href="{{route('inicio.servicios')}}">Crear Ventas</a>
                        <i class="fas fa-cart-arrow-down"></i>
                        <button class="navbar-toggler d-lg-none" type="button" data-toggle="collapse" data-target="#collapsibleNavId" aria-controls="collapsibleNavId" aria-expanded="false" aria-label="Toggle navigation"></button>
                        <div class="collapse navbar-collapse" id="collapsibleNavId">
                            <ul class="navbar-nav mr-auto mt-2 mt-lg-0"></ul>
                        </div> -->
                    </nav>
                </div>
                <div class="card-body">
                    @if(session('info'))
                    <div class="alert alert-success">
                        {{session('info')}}
                        @endif
                    </div>
                    <table class="table table-hover table-sm">
                        <thead>
                            <tr>
                                <th>ID</th>
                                <th>DESCRIPCIÓN</th>
                                <th>PRECIO</th>
                            </tr>
                        </thead>
                        <tbody>
                            @foreach($productoss as $Productos)
                            <tr>
                                <td>
                                    {{$Productos->id}}
                                </td>
                                <td>
                                    {{$Productos->descripcion}}
                                </td>
                                <td>
                                    <i class="fas fa-dollar-sign"></i>
                                    {{$Productos->precio}}</td>
                                <td>
                                    <a href="{{ route('productos.editar',$Productos->id) }}" class="btn btn-outline-success btn-sm">Editar</a>
                                    <a><i class="fas fa-file"></i></a>
                                    <a href="javascript: document.getElementById('delete-{{$Productos->id}}').submit()" class="btn btn-danger btn-sm">Eliminar</a>
                                    <a><i class="fa fa-trash"></i></a>
                                    <form id="delete-{{$Productos->id}}" action="{{route('productos.eliminar',$Productos->id)}}" method="POST">
                                        @method('delete')
                                        @csrf
                                    </form>
                                </td>
                            </tr>
                            @endforeach
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>
</div>
@endsection
