@extends('layouts.main')
@section('contenido')
<div class="container"><br>
    <div class="row">
        <div class="col-md-12">
            <div class="card">
                <!-- muestra un listado de columnas de forma de tarjetas-->
                <div class="card-header">
                    Listado de Productos
                </div>
                <div class="card-body">
                    @if(session('info'))
                    <div class="alert alert-success">
                        {{session('info')}}
                        @endif
                    </div>
                    <table class="table table-hover table-sm">
                        <thead>
                            <tr>
                                <th>Descrición</th>
                                <th>Precio</th>
                                <th>Acción</th>
                            </tr>
                        </thead>
                        <tbody>
                            @foreach($productos as $Productos)
                            <tr>
                                <td>
                                    {{$Productos->descripcion}}
                                </td>
                                <td>{{$Productos->precio}}</td>
                                <td>
                                    <a href="{{ route('productos.editar',$Productos->id) }}" class="btn btn-outline-success btn-sm">Editar</a>
                                    <a href="javascript: document.getElementById('delete-{{$Productos->id}}').submit()" class="btn btn-danger btn-sm">Eliminar</a>
                                    <form id="delete-{{$Productos->id}}" action="{{route('productos.eliminar',$Productos->id)}}" method="POST">
                                        @method('delete')
                                        @csrf
                                    </form>
                                </td>
                            </tr>
                            @endforeach
                        </tbody>
                    </table>
                </div>
                <div class="card-footer">
                    Bienvenido {{ auth()->user()->name }}
                    <a href="javascript:document.getElementById('logout').submit()" class="btn btn-outline-info float-right">Cerrar sesión</a>
                    <form action="{{ route('logout') }}" id="logout" style="display:none" method="POST">
                        @csrf
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
</div>
@endsection
