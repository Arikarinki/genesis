@extends('layouts.main')
@section('contenido')
<div class="container"><br>
    <div class="row">
        <div class="col-md-12">
            <div class="card">
                <!-- muestra un listado de columnas de forma de tarjetas-->
                <div class="card-header">
                    Editar Proveedor
                </div>
                <div class="card-body">
                    <form action=""{{ route('proveedores.update',$proveeedor->id)}}"" method="POST">
                        @csrf
                        <div class="form-group>">
                            <label for="">Nombre</label>
                            <input type="text" name="nombre" value="{{ $proveeedor->nombre }}" class="form-control">
                        </div>
                        <div class="form-group">
                            <label for="">Dirección</label>
                            <input type="text" name="direccion" value="{{ $proveeedor->direccion }}" class="form-control">
                        </div>
                        <div class="form-group">
                            <label for="">Número</label>
                            <input type="number" name="numero" value="{{ $proveeedor->numero }}" class="form-control">
                        </div>
                        <button type="submit" class="btn btn-outline-success">Guardar</button>
                        <a href="{{route('proveedor.indexProveedor')}}" class="btn btn-danger">Cancelar</a>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection
