@extends('layouts.main')
@section('contenido')
<style>
html, body {
                background-color:#2A2A2E;
                color: #636b6f;
                font-family: 'Nunito', sans-serif;
                font-weight: 2100;
                height: 100vh;
                margin: 10;
            }
            </style>
<div class="container"><br>

    <div class="row">
        <div class="col-md-12">
            <div class="card">
                <!-- muestra un listado de columnas de forma de tarjetas-->
                <div class="card-header">
                    <a href="{{ route('inicio.name')}}" class="btn btn-warning btn-sm float-right">Regresar</a>
                    Proveedores
                    <a href="{{route('proveedor.createP')}}" class="btn btn-success btn-sm float-right">Agregar Nuevo Proveedor</a>
                </div>
                <div class="card-body">
                    @if(session('info'))
                    <div class="alert alert-success">
                        {{session('info')}}
                        @endif
                    </div>
                    <table class="table table-hover table-sm">
                        <thead>
                            <tr>
                                <th>ID</th>
                                <th>NOMBRE</th>
                                <th>DIRECCIÓN</th>
                                <th>TELEFONO</th>
                            </tr>
                        </thead>
                        <tbody>
                            @foreach ($proveedor as $proverss)
                            <tr>
                                <td>
                                    {{ $proverss->id  }}
                                </td>
                                <td>
                                    {{ $proverss->nombre  }}
                                </td>
                                <td>
                                    {{ $proverss->direccion  }}
                                </td>
                                <td>
                                    {{ $proverss->numero }}
                                </td>
                                <td>
                                    <a href="{{route('proveedor.editarP',$proveeedor->id)}}" class="btn btn-outline-success btn-sm">Editar</a>
                                    <a href="javascript: document.getElementById('delete-{{  }}$proveedor->id}}').submit()" class="btn btn-danger btn-sm">Eliminar</a>
                                    <form id="delete-{{ $proverss->id }}" action="{{route('proveedor.eliminar',$proveedor->id)}}" method="POST">
                                        @method('delete')
                                        @csrf
                                    </form>
                                    <!-- <a href="" class="btn btn-outline-success btn-sm">Consultar</a>
                                        <a href="" class="btn btn-primary btn-sm">Imprimir</a>-->
                                </td>
                            </tr>
                            @endforeach
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>
</div>
@endsection
