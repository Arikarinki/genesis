@extends('layouts.main')
@section('contenido')
<style>
    html,
    body {
        background-color: #2A2A2E;
        color: whitesmoke;
        font-family: 'Nunito', sans-serif;
        font-weight: 2100;
        height: 100vh;
        margin: 10;
    }
    p {
        color: black;
        font-family: 'Nunito', sans-serif;
        margin: 10;
    }
</style>
<div class="container"><br>
    <div class="row">
        <div class="col-md-12">
            <div class="card">
                <!-- muestra un listado de columnas de forma de tarjetas-->
                <div class="card-header">
                    <p class="font-weight-bold">Venta de Productos</p>
                    <p><i class="fa fa-folder-open"></i></p>
                </div>
                <div class="container">
                    <a href="{{ route('inicio.name')}}" class="btn btn-danger btn-sm float-right">Cancelar</a>
                </div>
                <div class="card-body">
                    @if(session('info'))
                    <div class="alert alert-success">
                        {{session('info')}}
                        @endif
                    </div>
                    <table class="table table-hover table-sm">
                        <thead>
                            <tr>
                                <th>Producto</th>
                                <th>Marca</th>
                                <th>Proveedor</th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr>
                                <td>
                                    <select class="form-control" id="exampleFormControlSelect1">
                                        @foreach($productoss as $p)
                                            <option value="{{$p->descripcion}}">{{$p->descripcion}}</option>
                                        @endforeach
                                    </select>
                </div>
                </td>
                    @foreach($productoss as $p)
                            <option value="{{$p->descripcion}}">{{$p->descripcion}}</option>
                    @endforeach
                <td>
                    <select class="form-control" id="exampleFormControlSelect1">
                        @foreach($newMarcas as $nm)
                            <option value="{{ $nm->nombre }}">{{ $nm->nombre }}</option>
                        @endforeach
                    </select>
            </div>
            </td>
            <td>
                <select class="form-control" id="exampleFormControlSelect1">
                    @foreach($proveedor as $pro)
                        <option value="{{ $pro->nombre }}">{{ $pro->nombre }}</option>
                    @endforeach
                </select>
        </div>

        </td>
        <td>
            <a href="{{route('ventas.ventasreporte')}}" class="btn btn-outline-success btn-sm">Vender</a>
            <a><i class="fas fa-cart-arrow-down"></i></a>
        </td>
        </tr>
        </tbody>
        </table>
    </div></div></div>
</div>
@endsection
