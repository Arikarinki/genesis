<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <title>Document</title>
</head>
<body>
    <div class="container">
        <div class="card-header">
            <h2>Venta</h2>
        </div>
        <div class="row">
            <div class="col-md-12">
                <div class="card">
                    <!-- muestra un listado de columnas de forma de tarjetas-->
                    <table class="table table-hover table-sm">
                        <thead>
                            <tr>
                                <th>Productos</th>
                                <th>Marcas</th>
                                <th>Proveedor</th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr>
                                <td>
                                    @foreach($productoss as $p)
                                        <option value="{{$p->descripcion}}">{{$p->descripcion}}</option>
                                    @endforeach
                                </td>
                                <td>
                                    @foreach($productoss as $p)
                                        <option value="{{$p->descripcion}}">{{$p->descripcion}}</option>
                                    @endforeach
                                </td>
                                <td>
                                    @foreach($newMarcas as $nm)
                                        <option value="{{ $nm->nombre }}">{{ $nm->nombre }}</option>
                                    @endforeach
                                </td>
                            </tr>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</body>

</html>
