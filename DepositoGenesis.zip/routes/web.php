<?php

use Illuminate\Http\Request;
use App\Proveedores;
use App\Ventas;
use App\Servicios;
use App\Marcas;


use App\Productos;
use App\Http\Controllers\HomeController;
use App\Categorias;
//vistas fueras de middleware

Route::get('quiensSomos', function () {
    return view('vistas.quienSomos');
})->name('vistas.inicio1');

Route::get('quienesSomos', function () {
    return view('vistas.quienesSomos');
})->name('vistas.inicio2');


/////////////////
Route::get('inicio', function () {
    return view('layouts.welcome');
})->name('productos.inicio');

Route::middleware('auth')->group(function () {

    Route::get('productos', function () {
        $productoss = Productos::all();
        return view('productos.index', compact('productoss'));
        //mostrar todo el listado de
        //de productos en el parametro compact a la vista index
    })->name('inicio.name');

    Route::get('productosv', function () {
        $productoss = Productos::all();
        return view('ventas.compra', compact('productoss'));

    })->name('inicio.servicios');

    Route::get('create', function () {
        return view('productos.create');
    })->name('productos.create');

    Route::post('product', function (Request $request) {
        $newProducto = new Productos;
        $newProducto->descripcion = $request->input('descripcion');
        $newProducto->precio = $request->input('precio');
        $newProducto->save();
        return redirect()->route('inicio.name')->with('info', 'Producto creado exitosamente');
    })->name('productos.guardar');

    Route::delete('productosEliminados/{id}', function ($id) { //ruta para eliminar
        $product = Productos::findOrFail($id); //encontrar el id y en caso de fallar mandar error 404
        $product->delete(); //metodo eliminar
        return redirect()->route('inicio.name')->with('info', 'Producto eliminado Exitosamente');
    })->name('productos.eliminar');

    Route::get('productos/{id}/edit', function ($id) {
        $product = Productos::findOrFail($id); //encontrar el id y en caso de fallar mandar error 404
        return view('productos.edit', compact('product')); //retornar
    })->name('productos.editar');

    Route::put('/productos/{id}', function (request $request, $id) {
        $product = Productos::findOrFail($id);
        $product->descripcion = $request->input('descripcion'); //va a ser igual al imput que hace refencia en el formulario
        $product->precio = $request->input('precio'); //va a ser igual al imput que hace refencia en el formulario
        $product->save();
        return redirect()->route('inicio.name')->with('info', 'Producto Actualizado Exitosamente');
    })->name('productos.update');

    //ruta de la vista proveedor
        Route::get('proveedor', function () {
        //nombre del modelo de la tabla proveedor
        $proveedor = Proveedores::all();
        //y la vista se llama proveedor.blade.php
        return view('proveedores.proveedor', compact('proveedor'));
        //en compact alamacena todo lo que hay en la tabla proveedor
    })->name('proveedor.indexProveedor');//nombre de la ruta
//ruta del formulario
    Route::get('createP', function () {
        return view('proveedores.createP');
    })->name('proveedor.createP');

    //guardar proveddores a la tabla proveedor
    Route::post('proveedor', function (Request $request) {
        //return $request->all();
        $newProveedor = new Proveedores;
        $newProveedor->nombre = $request->input('nombre');//captura todo
        // lo que hay en el input
        $newProveedor->direccion = $request->input('direccion');
        $newProveedor->numero = $request->input('telefono');
        $newProveedor->save();
        return redirect()->route('proveedor.indexProveedor')
        ->with('info', 'Proveedor Agregado exitosamente');
    })->name('proveedor.guardarP');

    Route::delete('proveedorEliminados/{id}', function ($id) { //ruta para eliminar
        $proveedor = Proveedores::findOrFail($id); //encontrar el id y en caso de fallar mandar error 404
        $proveedor->delete(); //metodo eliminar
        return redirect()->route('proveedor.indexProveedor')->with('info', 'Proveedor eliminado Exitosamente');
    })->name('proveedor.eliminar');

    Route::get('proveedor/{id}/editP', function ($id) {
        //  return view('proveedores.editP');
        $proveedor = Proveedores::findOrFail($id); //encontrar el id y en caso de fallar mandar error 404
        return view('proveedores.editP', compact('proverss')); //retornar
    })->name('proveedor.editarP');

    Route::put('/proveedores/{id}', function (request $request, $id) {
        $proveeedor = Proveedores::findOrFail($id);
        $proveeedor->nombre = $request->input('nombre');
        $proveeedor->direccion = $request->input('direccion'); //va a ser igual al imput que hace refencia en el formulario
        $proveeedor->numero = $request->input('telefono'); //va a ser igual al imput que hace refencia en el formulario
        $proveeedor->save();
        return redirect()->route('proveedor.indexProveedor')->with('info', 'Producto Actualizado Exitosamente');
    })->name('productos.update');

    //ruta reporte
    Route::get('reportesventa', 'HomeController@ventacompra')
        //ruta hacia el controlador
        ->name('ventas.ventasreporte');

    Route::get('reportes', 'HomeController@reporte')
        //ruta hacia el controlador
        ->name('ventas.reporte');
    Route::get('ventasdd', 'HomeController@ventaindex')
        //ruta hacia el controlador

        ->name('ventas.connsulta');
    //consulta a ids'
    Route::get('ventasddd', 'HomeController@ventaindex1')
        //ruta hacia el controlador
        ->name('ventas.consulta1');



    //llenar ventas
    Route::post('ventasdd', function (Request $request) {
        $newVentas = new Ventas;
        $newVentas->id_users = $request->input('iduser');
        $newVentas->id_productos = $request->input('idprod');
        $newVentas->id_proveedores = $request->input('idprov');
        $newVentas->save();
        return redirect()->route('inicio.name');
    })->name('ventas.guardar');
    //vista llenarReporte
    Route::get('llenarReporte', function () {
        $productos = Productos::all();
        return view('ventas.llenarreporte', compact('productos')); //mostrar todo el listado de
        //de productos en el parametro compact a la vista index
    })->name('inicio.generar');

    Route::get('llenarconsulta', function () {
        $productos = Productos::all();
        return view('ventas.llenarreporte', compact('productos')); //mostrar todo el listado de
        //de productos en el parametro compact a la vista index
    })->name('inicio.consulta');





    Route::get('compra', function () {
        return view('ventas.compra');
    })->name('compra.compras');
    Route::get('createS', function () {
        return view('negocios.CreateS');
    })->name('crateS.crear');
     //servicios


    //llenar tabla de servicio
    Route::post('servicio', function (Request $request) {
        $newServicio = new Servicios;
        $newServicio->nombre = $request->input('nombre');

        $newServicio->save();
        return redirect()->route('service.servicios')->with('info', 'Servicio Ingresado exitosamente!!!');
    })->name('servicio.guardarS');

    //mostrar contenido en servicios
    /*Route::get('servicioscont', function () {
    $servicioss = Servicios::all();
    return view('negocios.servicios', compact('servicioss')); //mostrar todo el listado de
    //de productos en el parametro compact a la vista index
})->name('servicioscont.nameservice');*/

    //ruta de crear categoria
    Route::get('createC', function () {
        return view('negocios.CreeateC');
    })->name('crateC.crearC');
    //llenar tabla de categoria
    Route::post('sevicess', function (Request $request) {
        $newCategoria = new Categorias();
        $newCategoria->nombre = $request->input('nombre');

        $newCategoria->save();
        return redirect()->route('categorias.categorias')
        ->with('info', 'Categoria Ingresado exitosamente!!!');
    })->name('productos.guardarcategory');

    //ruta marcas crear
    Route::get('createM', function () {
        return view('negocios.Crearmarcas');
    })->name('crateM.crearM');
    //llenar tabla de Marcas
    Route::post('marcas', function (Request $request) {
        $newMarcas = new Marcas();
        $newMarcas->nombre = $request->input('nombre');
        $newMarcas->save();
        return redirect()->route('marcass.marcass')->with('info', 'Marca Ingresado exitosamente!!!');
    })->name('productos.guardarmarcas');
    //Mostrar de datos  tabla servicio
    Route::get('serviciosL', 'HomeController@servicio')
    //ruta hacia el controlador

    ->name('service.servicios');
    //elminar servicio
    Route::delete('servicioEliminados/{id}', function ($id) { //ruta para eliminar
        $servicios = Servicios::findOrFail($id); //encontrar el id y en caso de fallar mandar error 404
        $servicios->delete(); //metodo eliminar
        return redirect()->route('negocios.servicios')->with('info', 'Servicio eliminado Exitosamente');
    })->name('negocios.eliminar');
    //Mostrar tabla categoria
    Route::get('categorias', 'HomeController@categoria')
    //ruta hacia el controlador

    ->name('categorias.categorias');
    //Mostrar tabla categoria
    Route::get('marcas', 'HomeController@marcas')
    //ruta hacia el controlador

    ->name('marcass.marcass');
});







Auth::routes();
