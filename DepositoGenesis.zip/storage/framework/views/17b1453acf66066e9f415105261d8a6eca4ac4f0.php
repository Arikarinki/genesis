<?php $__env->startSection('contenido'); ?>
<div class="container"><br>

    <div class="row">
        <div class="col-md-12">
            <div class="card"><!-- muestra un listado de columnas de forma de tarjetas-->
                <div class="card-header">
                      
                        <a href="<?php echo e(route('proveedor.indexProveedor')); ?>"class ="btn btn-success btn-sm float-right">proveedores</a>
                    Listado de Productos
                    
                    <a href="<?php echo e(route('productos.create')); ?>" class="btn btn-primary btn-sm float-right">Nuevo Producto</a>
                    <a href="<?php echo e(route('reporte')); ?>" class="btn btn-outline-primary btn-sm float-right">Imprimir Reporte</a>
                    </div>
                    <div class="card-body">
                            
                            <?php if(session('info')): ?>
                            <div class="alert alert-success">
                                <?php echo e(session('info')); ?>

                                <?php endif; ?>
                                </div>
                           
                                <table class="table table-hover table-sm">
                                    <thead>
                                        <tr>
                                            <th>Descrición</th>
                                            <th>Precio</th>
                                            <th>Acción</th>
                                
                                        </tr>
                                    </thead>
                                    <tbody>
                                    <?php $__currentLoopData = $productos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $Productos): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                          
                                            <td>
                                            <?php echo e($Productos->descripcion); ?>

                                            </td>
                                            <td><?php echo e($Productos->precio); ?></td>
                                            <td>
                                                <a href="<?php echo e(route('productos.editar',$Productos->id)); ?>" class="btn btn-outline-success btn-sm">Editar</a>
                                                <a href="javascript: document.getElementById('delete-<?php echo e($Productos->id); ?>').submit()" class="btn btn-danger btn-sm">Eliminar</a>
                                                <form id="delete-<?php echo e($Productos->id); ?>" action="<?php echo e(route('productos.eliminar',$Productos->id)); ?>" method="POST">
                                                <?php echo method_field('delete'); ?>
                                                <?php echo csrf_field(); ?>
                                                
                                                </form>
                                                
                                            </td>
                                            
                                        </tr>
                                     <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                                                </div>
                                                <div class="card-footer">
                                                    Bienvenido <?php echo e(auth()->user()->name); ?>   
                                                     <a href="javascript:document.getElementById('logout').submit()" 
                                                     class ="btn btn-outline-info float-right">Cerrar sesión</a>
                                                      <form action="<?php echo e(route('logout')); ?>" id="logout" 
                                                      style="display:none" method="POST">
                                                      <?php echo csrf_field(); ?>   
                                                     
                                                       </form>
                                                     </div>
                                               
                      
                        </div>  
               </div> 
            </div> 
        </div> 
    </div>  
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/haniel/Imágenes/Proyecto_Laravel_pendiente/resources/views/productos/index.blade.php ENDPATH**/ ?>