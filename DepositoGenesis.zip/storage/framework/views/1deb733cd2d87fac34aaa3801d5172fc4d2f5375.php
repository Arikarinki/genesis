<!doctype html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <title>Laravel</title>

    <!-- Fonts -->

    <link rel="stylesheet" href="css/bootstrap.min.css">
    <!-- Styles -->
    <style>
        html,
        body {
            background-color: #2A2A2E;
            color: #636b6f;
            font-family: 'Nunito', sans-serif;
            font-weight: 2100;
            height: 100vh;
            margin: 10;
        }


        .full-height {
            height: 100vh;
        }

        .flex-center {
            align-items: center;
            display: flex;
            justify-content: center;
        }

        .position-ref {
            position: relative;
        }

        .top-right {
            position: absolute;
            right: 10px;
            top: 18px;
        }

        .content {
            text-align: center;
        }

        .title {
            font-size: 90px;
        }

        .links>a {
            color: #636b6f;
            padding: 0 25px;
            font-size: 13px;
            font-weight: 600;
            letter-spacing: .1rem;
            text-decoration: none;
            text-transform: uppercase;
        }

        .m-b-md {
            margin-bottom: 30px;
        }
    </style>
</head>

<body>
    <div class="container">

        <h1 class="display-4">Tienda de Productos</h1>
        <nav class="my-2 my-md-0 mr-md-3">
            <div class="flex-center position-ref full-height">
                <?php if(Route::has('login')): ?>
                <div class="top-right links">
                    <?php if(auth()->guard()->check()): ?>
                    <a href="<?php echo e(url('/inicio')); ?>">Inicio</button>
                        <?php else: ?>
                        <a href="<?php echo e(route('login')); ?>" class="btn btn-outline-primary">Iniciar Sesión</a>

                        <?php if(Route::has('register')): ?>
                        <a href="<?php echo e(route('register')); ?>" class="btn btn-outline-success">Registrar</a>
                        <?php endif; ?>
                        <?php endif; ?>
                </div>
                <?php endif; ?>


                <div>
                    <br>
                    <br>
                    <br>
                    <br>
                    <br>
                    <br>
                    <br>
                    <br>
                    <br>
                    <br>
                    <br>
                    <br>


                    <img src="img/tienda.jpg" class="img-thumbnail" alt="Responsive image">




                </div>

            </div>

    </div>

</body>

</html><?php /**PATH C:\laragon\www\Proyecto_Laravel_pendiente\resources\views/layouts/welcome.blade.php ENDPATH**/ ?>