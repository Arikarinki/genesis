<!doctype html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <title>Laravel</title>

    <!-- Fonts -->

    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="js/bootstrap.min.js">
    <link rel="stylesheet" href="js/popper.min.js">
    <link rel="stylesheet" href="js/jquery-3.3.1.slim.min.js">
    <link rel="stylesheet" href="js/jquery.js">



    <style>
        .fondo {
            background-image: url(img/fondo5.jpg);
        }

        .footer {
            background: black;
            color: white;
        }

        a,
        i {
            background: black;
            color: white;
        }
    </style>

</head>

<body class='fondo'>
    <nav class="navbar navbar-expand-sm navbar-dark bg-dark">

        <button class="navbar-toggler d-lg-none" type="button" data-toggle="collapse" data-target="#collapsibleNavId" aria-controls="collapsibleNavId" aria-expanded="false" aria-label="Toggle navigation"></button>
        <div class="collapse navbar-collapse" id="collapsibleNavId">
            <ul class="navbar-nav mr-auto mt-2 mt-lg-0">
            <li role="presentation" ><a href="<?php echo e(route('productos.inicio')); ?>" class="a"><h4 class="h"><img class="imagen" width="120" heigth="10000" src="img/icono.jpg"></h4></a></li>
                <li class="nav-item active">
                    <a class="nav-link" href="<?php echo e(route('vistas.inicio2')); ?>">Quienes somos? <span class="sr-only">(current)</span></a>
                </li>
                <li class="nav-item active">
                    <a class="nav-link" href="#">Acerca <span class="sr-only">(current)</span></a>
                </li>
                <li class="nav-item active">
                    <a class="nav-link" href="#">Trabaja con Nosotros <span class="sr-only">(current)</span></a>
                </li>
                <li class="nav-item active">
                    <a class="nav-link" href="<?php echo e(route('vistas.inicio1')); ?>">Nuesta Visión <span class="sr-only">(current)</span></a>
                </li>

            </ul>
            <form class="form-inline my-2 my-lg-0">
                <a class="navbar-brand" href="<?php echo e(route('login')); ?>" class="btn btn-outline-primary"> Iniciar Sesión </a>
                <a class="navbar-brand" href="<?php echo e(route('register')); ?>" class="btn btn-outline-primary">Registrar </a>

            </form>
        </div>
    </nav>
    <div class="container">

        <nav>

        </nav>
        <div id="switcher">
            <div class="center">
                <div class="responsive">
                    <div class="flex-center position-ref full-height">
                        <?php if(Route::has('login')): ?>
                        <div class="top-right links">
                            <?php if(auth()->guard()->check()): ?>
                            <a href="<?php echo e(url('/inicio')); ?>">Inicio</button>
                                <?php else: ?>


                                <?php if(Route::has('register')): ?>

                                <?php endif; ?>
                                <?php endif; ?>
                        </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>

    </div>
    <br>
    <div class="footer">
        <div class="card bg-dark">
            <div class="card-body">
                <h5 class="card-title">MISIÓN </h5>
                <a class="card-text">Suministrar sistemas de seguridad y telecomunicaciones
                    con la más avanzada tecnología de transmisión de datos,
                    conmutación de datos, comunicación satelital e integración de sistemas a
                    un mercado de clientes en constante crecimiento,
                    los cuales requieren del uso de una infraestructura sólida,
                    que les permita avanzar hacia nuevos horizontes de manera segura y
                    coordinada.</a>
                <br>
                <br>
                <h5 class="card-title">VISIÓN </h5>


                <a class="card-text">Ser una empresa que cumpla con los estándares de calidad en servicios
                    de seguridad y telecomunicaciones para sus clientes, estableciendo relaciones comerciales
                    con proveedores con tecnología de punta para ofrecer lo mejor y extenderse e el mercado.
                    POSICIÓN DE LA EMPRESA.
                </a>

                <p class="card-text"><small class="text-muted">Ing. Gsutavo González García    FUNDADOR Y CREADOR DE LA EMPRESA</small></p>
            </div>

        </div>
    </div>

    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
  <div class="footer">
    <div class="card bg-dark">
      <div class="card-body">
        <h5 class="card-title">Dirección</h5>
        <a class="card-text">SESETEL tiene su ubicación en la comunidad de San Felipe Coamango, Ejido Chapa de Mota. 54384.</a>
        <p class="card-text"><small class="text-muted">Derechos de autor Gustavo</small></p>
      </div>
    </div>
  </div>

    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>

</body>

</html><?php /**PATH C:\laragon\www\Gustavo\resources\views/vistas/quienSomos.blade.php ENDPATH**/ ?>