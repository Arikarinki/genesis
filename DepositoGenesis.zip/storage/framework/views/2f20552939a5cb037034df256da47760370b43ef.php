<?php $__env->startSection('contenido'); ?>
<style>
    html,
    body {
        background-color: #2A2A2E;
        color: whitesmoke;
        font-family: 'Nunito', sans-serif;
        font-weight: 2100;
        height: 100vh;
        margin: 10;
    }

    p {

        color: black;
        font-family: 'Nunito', sans-serif;


        margin: 10;
    }
</style>

<div class="container"><br>

    <ul class="nav nav-pills nav-fill">
        <li class="nav-item">
            <a class="nav-link active" href="<?php echo e(route('productos.create')); ?>">Nuevo Producto</a>
        </li>
        <li class="nav-item">
            <a class="nav-link active " href="<?php echo e(route('proveedor.indexProveedor')); ?>">Proveedores</a>
        </li>
        <li class="nav-item">
            <a class="nav-link active" href="<?php echo e(route('service.servicios')); ?>">Servicios</a>
        </li>
        <li class="nav-item">
            <a class="nav-link active  " href="<?php echo e(route('categorias.categorias')); ?>">Categorias</a>
        </li>
        <li class="nav-item">
            <a class="nav-link active " href="<?php echo e(route('marcass.marcass')); ?>">Marcas</a>
        </li>
    </ul>


    <div class="row">
        <div class="col-md-12">
            <div class="card">
                <!-- muestra un listado de columnas de forma de tarjetas-->
                <div class="card-header">
                    <p class="font-weight-bold">Listado de Productos. </p>

                    <p><i class="fa fa-folder-open"></i></p>
                </div>

                <div class="container">



                    <ul class="nav nav-pills nav-fill">
            
                        <!--#############################-->
                        <li class="nav-item">
                        <p> <a href="<?php echo e(route('ventas.ventasreporte')); ?>" class="btn btn-outline-success btn-sm ">Imprimir Venta</a>
                            <i class="fas fa-print"></i></p>
                            </li>
                       
                        <li class="nav-item">
                        <p> <a href="<?php echo e(route('ventas.reporte')); ?>" class="btn btn-primary btn-sm ">Imprimir Reporte</a>
                            <i class="fas fa-print"></i></p>
                            </li>
                        <li class="nav-item">
                        <p> <a href="<?php echo e(route('compra.compras')); ?>" class="btn btn-outline-success btn-sm">Generar Venta</a>
                            <i class="fas fa-cart-arrow-down"></i></p>
                            </li>
                    </ul>
                </div>
                <div class="card-body">

                    <?php if(session('info')): ?>
                    <div class="alert alert-success">
                        <?php echo e(session('info')); ?>

                        <?php endif; ?>
                    </div>

                    <table class="table table-hover table-sm">
                        <thead>
                            <tr>
                                <th>Descrición</th>
                                <th>Precio</th>
                                <th>Acción</th>

                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $productoss; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $Productos): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>

                                <td>
                                  <?php echo e($Productos->descripcion); ?>

                                </td>
                                <td>
                                  <?php echo e($Productos->precio); ?></td>
                                <td>

                                    <a href="<?php echo e(route('productos.editar',$Productos->id)); ?>" class="btn btn-outline-success btn-sm">Editar</a>
                                    <a><i class="fas fa-file"></i></a>
                                    <a href="javascript: document.getElementById('delete-<?php echo e($Productos->id); ?>').submit()" class="btn btn-danger btn-sm">Eliminar</a>
                                    <a><i class="fa fa-trash"></i></a>
                                    <form id="delete-<?php echo e($Productos->id); ?>" action="<?php echo e(route('productos.eliminar',$Productos->id)); ?>" method="POST">
                                        <?php echo method_field('delete'); ?>
                                        <?php echo csrf_field(); ?>

                                    </form>

                                </td>

                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
                <div class="card-footer">
                    <a class="font-weight-bold">Bienvenido ING. </a> <?php echo e(auth()->user()->name); ?>



                    <i class="fas fa-user"></i>
                    <a href="javascript:document.getElementById('logout').submit()" class="btn btn-outline-info float-right">Cerrar sesión</a>
                    <form action="<?php echo e(route('logout')); ?>" id="logout" style="display:none" method="POST">
                        <?php echo csrf_field(); ?>

                    </form>

                </div>


            </div>
        </div>
    </div>
</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\Proyecto_Laravel_pendiente\resources\views/productos/index.blade.php ENDPATH**/ ?>