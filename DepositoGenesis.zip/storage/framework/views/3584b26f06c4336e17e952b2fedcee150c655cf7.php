<?php $__env->startSection('contenido'); ?>
<style>
    html,
    body {
        background-image: <source><img src="fondo1"alt="">;
        color: whitesmoke;
        font-family: 'Nunito', sans-serif;
        font-weight: 2100;
        height: 100vh;
        margin: 10;
    }

    p {

        color: black;
        font-family: 'Nunito', sans-serif;


        margin: 10;
    }

    html,
    body,
    header,
    #intro {
        height: 100%;
    }



    body {}
</style>

<div class="container"><br>

    <div id="intro" class="view">
        <div class="full-bg-img">
        </div>


    </div>



    <div class="row">
        <div class="col-md-12">
            <div class="card">
                <!-- muestra un listado de columnas de forma de tarjetas-->
                <div class="card-header">
                    <p class="font-weight-bold">Listado de Productos. </p>

                    <p><i class="fa fa-folder-open"></i></p>
                </div>

                <div class="container">



                    <nav class="navbar navbar-expand-sm navbar-dark bg-dark">
                        <a class="navbar-brand" href="<?php echo e(route('ventas.guardar')); ?>">Llenar reporte por producto</a>
                        <i class="fas fa-print"></i>
                        <button class="navbar-toggler d-lg-none" type="button" data-toggle="collapse" data-target="#collapsibleNavId" aria-controls="collapsibleNavId" aria-expanded="false" aria-label="Toggle navigation"></button>
                        <div class="collapse navbar-collapse" id="collapsibleNavId">
                            <ul class="navbar-nav mr-auto mt-2 mt-lg-0">

                            </ul>

                        </div>

                        <button class="navbar-toggler d-lg-none" type="button" data-toggle="collapse" data-target="#collapsibleNavId" aria-controls="collapsibleNavId" aria-expanded="false" aria-label="Toggle navigation"></button>
                        <div class="collapse navbar-collapse" id="collapsibleNavId">
                            <ul class="navbar-nav mr-auto mt-2 mt-lg-0">

                            </ul>

                        </div>
                        <a class="navbar-brand" href="<?php echo e(route('ventas.reporte')); ?>">Imprimir Reporte</a>
                        <i class="fas fa-print"></i>
                        <button class="navbar-toggler d-lg-none" type="button" data-toggle="collapse" data-target="#collapsibleNavId" aria-controls="collapsibleNavId" aria-expanded="false" aria-label="Toggle navigation"></button>
                        <div class="collapse navbar-collapse" id="collapsibleNavId">
                            <ul class="navbar-nav mr-auto mt-2 mt-lg-0">

                            </ul>

                        </div>
                        <a class="navbar-brand" href="<?php echo e(route('inicio.servicios')); ?>">Crear Ventas</a>
                        <i class="fas fa-cart-arrow-down"></i>
                        <button class="navbar-toggler d-lg-none" type="button" data-toggle="collapse" data-target="#collapsibleNavId" aria-controls="collapsibleNavId" aria-expanded="false" aria-label="Toggle navigation"></button>
                        <div class="collapse navbar-collapse" id="collapsibleNavId">
                            <ul class="navbar-nav mr-auto mt-2 mt-lg-0">

                            </ul>

                        </div>
                    </nav>
                </div>
                <div class="card-body">

                    <?php if(session('info')): ?>
                    <div class="alert alert-success">
                        <?php echo e(session('info')); ?>

                        <?php endif; ?>
                    </div>

                    <table class="table table-hover table-sm">
                        <thead>
                            <tr>
                                <th>Descrición</th>
                                <th>Precio</th>
                                <th>Acción</th>

                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $productoss; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $Productos): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>

                                <td>
                                    <?php echo e($Productos->descripcion); ?>

                                </td>
                                <td>
                                    <i class="fas fa-dollar-sign"></i>
                                    <?php echo e($Productos->precio); ?></td>
                                <td>

                                    <a href="<?php echo e(route('productos.editar',$Productos->id)); ?>" class="btn btn-outline-success btn-sm">Editar</a>
                                    <a><i class="fas fa-file"></i></a>
                                    <a href="javascript: document.getElementById('delete-<?php echo e($Productos->id); ?>').submit()" class="btn btn-danger btn-sm">Eliminar</a>
                                    <a><i class="fa fa-trash"></i></a>
                                    <form id="delete-<?php echo e($Productos->id); ?>" action="<?php echo e(route('productos.eliminar',$Productos->id)); ?>" method="POST">
                                        <?php echo method_field('delete'); ?>
                                        <?php echo csrf_field(); ?>

                                    </form>

                                </td>

                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>

                </div>



            </div>
        </div>
    </div>
</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\Gustavo\resources\views/productos/index.blade.php ENDPATH**/ ?>