<!doctype html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <title>Laravel</title>

    <!-- Fonts -->

    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="js/bootstrap.min.js">
    <link rel="stylesheet" href="js/popper.min.js">
    <link rel="stylesheet" href="js/jquery-3.3.1.slim.min.js">
    <link rel="stylesheet" href="js/jquery.js">



    <style>
        .fondo {
            background-image: url(img/fondo1.jpg);
        }

        .footer {
            background: black;
            color: white;
        }

        a,
        i {
            background: black;
            color: white;
        }
    </style>

</head>

<body class='fondo'>
    <nav class="navbar navbar-expand-sm navbar-dark bg-dark">

        <button class="navbar-toggler d-lg-none" type="button" data-toggle="collapse" data-target="#collapsibleNavId" aria-controls="collapsibleNavId" aria-expanded="false" aria-label="Toggle navigation"></button>
        <div class="collapse navbar-collapse" id="collapsibleNavId">
            <ul class="navbar-nav mr-auto mt-2 mt-lg-0">
                <li role="presentation"><a href="<?php echo e(route('productos.inicio')); ?>" class="a">
                        <h4 class="h"><img class="imagen" width="120" heigth="10000" src="img/icono.jpg"></h4>
                    </a></li>
                <li class="nav-item active">
                    <a class="nav-link" href="<?php echo e(route('vistas.inicio2')); ?>">Quienes somos? <span class="sr-only">(current)</span></a>
                </li>
                <li class="nav-item active">
                    <a class="nav-link" href="#">Acerca <span class="sr-only">(current)</span></a>
                </li>
                <li class="nav-item active">
                    <a class="nav-link" href="#">Trabaja con Nosotros <span class="sr-only">(current)</span></a>
                </li>
                <li class="nav-item active">
                    <a class="nav-link" href="<?php echo e(route('vistas.inicio1')); ?>">Nuesta Visión <span class="sr-only">(current)</span></a>
                </li>

            </ul>
            <form class="form-inline my-2 my-lg-0">
                <a class="navbar-brand" href="<?php echo e(route('login')); ?>" class="btn btn-outline-primary"> Iniciar Sesión </a>
                <a class="navbar-brand" href="<?php echo e(route('register')); ?>" class="btn btn-outline-primary">Registrar </a>

            </form>
        </div>
    </nav>
    <div class="container">

        <nav>

        </nav>
        <div id="switcher">
            <div class="center">
                <div class="responsive">
                    <div class="flex-center position-ref full-height">
                        <?php if(Route::has('login')): ?>
                        <div class="top-right links">
                            <?php if(auth()->guard()->check()): ?>
                            <a href="<?php echo e(url('/inicio')); ?>">Inicio</button>
                                <?php else: ?>


                                <?php if(Route::has('register')): ?>

                                <?php endif; ?>
                                <?php endif; ?>
                        </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>

    </div>
    <br>
    <div class="footer">
        <div class="card bg-dark">
            <div class="card-body">

                <h5 class="card-title">ANTECEDENTES HISTÓRICOS </h5>
                <center>
                    <li role="presentation"><a href="index.html" class="a">
                            <h4 class="h"><img class="imagen" width="520" heigth="10000" src="img/icono.jpg"></h4>
                        </a></li>
                </center>
                <a class="card-text">Servicios en Seguridad y Telecomunicaciones (SESETEL), es una empresa constituida en el año 2018, su función principal es dar atención al área de tecnología en telecomunicaciones y seguridad electrónica con el interés de atender exitosamente la gran demanda de servicios y sistemas de Telecomunicaciones de los sectores financieros, comercial, industrial y gubernamental que requieren mantener y mejorar sus niveles de competencia y crecimiento, así mismo ofrecer sistemas de seguridad que permitan a los clientes tener la confianza y el respaldo de crecer social y económicamente.


                    En un inicio la idea fue generada por el Ing. Gustavo González García, quien a partir de su experiencia decide crear SESETEL, en un principio para dar mantenimiento a equipos de cómputo, generar redes de internet y ofrecer algunos productos.

                    Progresivamente se ha ido diversificando y las áreas de especialización que maneja la empresa hasta ahora son:


                    Se proyecta que para el 2021 se abarquen áreas como:




                    UBICACIÓN

                    SESETEL tiene su ubicación en la comunidad de San Felipe Coamango, Ejido Chapa de Mota. 54384.
                </a>

                <center> <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d6307.295233724755!2d-99.53173157012438!3d19.952190937550274!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x85d2363d20f4af1d%3A0xdfc55b04b2920281!2s54240+Jilotepec%2C+M%C3%A9x.!5e0!3m2!1ses-419!2smx!4v1560954860156!5m2!1ses-419!2smx" width="600" height="450" frameborder="0" style="border:0" allowfullscreen></iframe></center>


                <p class="card-text"><small class="text-muted">Ing. Gsutavo González García FUNDADOR Y CREADOR DE LA EMPRESA</small></p>
            </div>

        </div>
    </div>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <div class="footer">
        <div class="card bg-dark">
            <div class="card-body">
                <h5 class="card-title">Dirección</h5>
                <a class="card-text">SESETEL tiene su ubicación en la comunidad de San Felipe Coamango, Ejido Chapa de Mota. 54384.</a>
                <p class="card-text"><small class="text-muted">Derechos de autor Gustavo</small></p>
            </div>
        </div>
    </div>



    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>

</body>

</html><?php /**PATH C:\laragon\www\Gustavo\resources\views/vistas/quienesSomos.blade.php ENDPATH**/ ?>