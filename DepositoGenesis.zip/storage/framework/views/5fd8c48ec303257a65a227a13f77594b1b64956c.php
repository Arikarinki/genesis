<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <title>Document</title>
</head>

<body>

    <div class="container">
        <div class="card-header">
            <h2> Reporte De Ventas</h2>

        </div>
        <div class="row">
            <div class="col-md-12">
                <div class="card">
                    <!-- muestra un listado de columnas de forma de tarjetas-->

                    <table class="table table-hover table-sm">
                        <thead>
                            <tr>
                               
                                <th>Productos</th>
                                <th>Precios</th>
                                <th>servicio</th>
                                <th>categoria</th>


                            </tr>
                        </thead>
                        <tbody>
                           
                            <tr>

                                

                                <td>...</td>
                                <td>... </td>
                                <td>...</td>
                                <td>...</td>


                            </tr>
                          
                        </tbody>
                    </table>
                </div>
            </div>


        </div>
        <div class="card-header">
            <h3>Gracias por su Compra!!!</h3>

        </div>
     
    </div>
</body>

</html><?php /**PATH C:\laragon\www\Proyecto_Laravel_pendiente\resources\views/ventas/ventareporte.blade.php ENDPATH**/ ?>