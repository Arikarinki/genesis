<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" href="css/bootstrap.min.css"> 
    <title>Laravel</title>
</head>
<body>
    <div class="container"><br>

        <div class="row">
         <div class="col-md-12">
          <div class="card"><!-- muestra un listado de columnas de forma de tarjetas-->                     
            <div class="card-header">
            Listado de Productos
       <a href="<?php echo e(route('productos.crear')); ?>" class="btn btn-primary btn-sm float-right">Nuevo Producto</a>
                 </div>
                 <div class="card-body">
                   
                   <div class="alert alert-success">
                  
                 <table class="table table-hover table-sm">
                   <thead>
                     <th>Descripcion</th>
                        <th>Precio</th>
  
                   </thead>
                    <tbody>
                      
                      <tr>
                        <td>
                          
                        </td>
                        <td>
                         
                          </td>
                      </tr>
                     
                  </tbody>
  
                 </table>
                   </div>  
               </div> 
           </div> 
        </div> 
</body>
</html><?php /**PATH /home/haniel/Descargas/Proyecto_Laravel/resources/views/productos/index.blade.php ENDPATH**/ ?>