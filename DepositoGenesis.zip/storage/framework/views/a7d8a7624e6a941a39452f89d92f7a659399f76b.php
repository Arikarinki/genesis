<?php $__env->startSection('contenido'); ?>
<div class="container"><br>
    <div class="row">
        <div class="col-md-12">
            <div class="card">
                <!-- muestra un listado de columnas de forma de tarjetas-->
                <div class="card-header">
                    Editar Proveedor

                </div>
                <div class="card-body">
                    <form action="" method="POST">

                        <?php echo csrf_field(); ?>
                        <div class="form-group>">
                            <label for="">Nombre</label>
                            <input type="text" name="nombre" value="" class="form-control">
                        </div>
                        <div class="form-group">
                            <label for="">Dirección</label>
                            <input type="text" name="direccion" value="" class="form-control">
                        </div>
                        <div class="form-group">
                            <label for="">Número</label>
                            <input type="number" name="numero" value="" class="form-control">
                        </div>
                        <button type="submit" class="btn btn-outline-success">Guardar</button>
                        <a href="<?php echo e(route('proveedor.indexProveedor')); ?>" class="btn btn-danger">Cancelar</a>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\Proyecto_Laravel_pendiente\resources\views/proveedores/editP.blade.php ENDPATH**/ ?>