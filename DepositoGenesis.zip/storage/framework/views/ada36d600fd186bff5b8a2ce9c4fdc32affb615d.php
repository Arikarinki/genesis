<?php $__env->startSection('contenido'); ?>
<style>
html, body {
                background-color:#2A2A2E;
                color: #636b6f;
                font-family: 'Nunito', sans-serif;
                font-weight: 2100;
                height: 100vh;
                margin: 10;
            }
            </style>
<div class="container"><br>

    <div class="row">
        <div class="col-md-12">
            <div class="card">
                <!-- muestra un listado de columnas de forma de tarjetas-->
                <div class="card-header">
                    <a href="<?php echo e(route('inicio.name')); ?>" class="btn btn-success btn-sm float-right">Regresar</a>
                    Listado de Proveedores
                    <a href="<?php echo e(route('proveedor.createP')); ?>" class="btn btn-primary btn-sm float-right">Agregar Nuevo Proveedor</a>

                </div>
                <div class="card-body">
                    <?php if(session('info')): ?>
                    <div class="alert alert-success">
                        <?php echo e(session('info')); ?>

                        <?php endif; ?>
                    </div>
                    <table class="table table-hover table-sm">
                        <thead>
                            <tr>
                                <th>Nombre</th>
                                <th>Dirección</th>
                                <th>Telefono</th>
                                <th>Acción</th>

                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $proveedor; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $proverss): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>

                                <td>
                                    <?php echo e($proverss->nombre); ?>

                                </td>
                                <td>
                                    <?php echo e($proverss->direccion); ?>

                                </td>
                                <td>
                                    <?php echo e($proverss->numero); ?>

                                </td>
                                <td>
                                    <a href="<?php echo e(route('proveedor.editarP',$proverss->id)); ?>" class="btn btn-outline-success btn-sm">Editar</a>
                                    <a href="javascript: document.getElementById('delete-<?php echo e($proverss->id); ?>').submit()" class="btn btn-danger btn-sm">Eliminar</a>
                                    <form id="delete-<?php echo e($proverss->id); ?>" action="<?php echo e(route('proveedor.eliminar',$proverss->id)); ?>" method="POST">
                                        <?php echo method_field('delete'); ?>
                                        <?php echo csrf_field(); ?>

                                    </form>

                                    <!-- <a href="" class="btn btn-outline-success btn-sm">Consultar</a>
                                                <a href="" class="btn btn-primary btn-sm">Imprimir</a>-->
                                </td>

                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>



            </div>
        </div>
    </div>
</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\Gustavo\resources\views/proveedores/proveedor.blade.php ENDPATH**/ ?>