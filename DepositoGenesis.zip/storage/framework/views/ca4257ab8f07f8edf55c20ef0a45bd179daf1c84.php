<?php $__env->startSection('contenido'); ?>
<style>
    html,
    body {
        background-color: #2A2A2E;
        color: whitesmoke;
        font-family: 'Nunito', sans-serif;
        font-weight: 2100;
        height: 100vh;
        margin: 10;
    }

    p {

        color: black;
        font-family: 'Nunito', sans-serif;


        margin: 10;
    }
</style>

<div class="container"><br>




    <div class="row">
        <div class="col-md-12">
            <div class="card">
                <!-- muestra un listado de columnas de forma de tarjetas-->
                <div class="card-header">
                    <p class="font-weight-bold">Listado de Productos. </p>

                    <p><i class="fa fa-folder-open"></i></p>
                </div>

                <div class="container">

                <a href="<?php echo e(route('inicio.name')); ?>" class="btn btn-danger btn-sm float-right">Cancelar</a>
               

                       
                   

                </div>
                <div class="card-body">

                    <?php if(session('info')): ?>
                    <div class="alert alert-success">
                        <?php echo e(session('info')); ?>

                        <?php endif; ?>
                    </div>

                    <table class="table table-hover table-sm">
                        <thead>
                            <tr>
                                <th>Descrición</th>
                                <th>Precio</th>
                                <th>Acción</th>

                            </tr>
                        </thead>
                        <tbody>
                          
                            <tr>

                                <td>
                                    
                                </td>
                                <td></td>
                                <td>

                                <a href="" class="btn btn-outline-success btn-sm">Vender</a>
                                    <a><i class="fas fa-cart-arrow-down"></i></a>
                                   
                                </td>

                            </tr>
                          
                        </tbody>
                    </table>
                </div>
               


            </div>
        </div>
    </div>
</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\Proyecto_Laravel_pendiente\resources\views/ventas/compra.blade.php ENDPATH**/ ?>