<?php $__env->startSection('contenido'); ?>
<style>
html, body {
                background-color:#2A2A2E;
                color: #636b6f;
                font-family: 'Nunito', sans-serif;
                font-weight: 2100;
                height: 100vh;
                margin: 10;
            }
            </style>
<div class="container">
    <div class="row">
        <div class="col-md-12">
            <div class="card"><!-- muestra un listado de columnas de forma de tarjetas-->
                <div class="card-header">
                    Generar Reporte
                   
                    </div>
                    <div class="card-body">
                            <form action="<?php echo e(route('ventas.guardar')); ?>" method="POST">
                            <?php echo csrf_field(); ?>
                           
                                <div class="form-group>">
                                <label for="">Id Usuario</label>
                              <input type="number" class="form-control" name="iduser"
                              placeholder="">
                            </div>
                            <div class="form-group">
                                <label for="">Id Producto</label>
                              <input type="number" class="form-control" name="idprod">
                          </div>  
                          <div class="form-group">
                                <label for="">Id Proveedor</label>
                              <input type="number" class="form-control" name="idprov">
                          </div> 
                          
                          <button type="submit" class="btn btn-primary">Guardar</button>
                          <a href="<?php echo e(route('inicio.name')); ?>" class="btn btn-danger">Cancelar</a>
                          </form>
                    </div>
                </div>         
            </div> 
        </div> 
       
        <div class="row">
            <div class="col-md-12">
                <div class="card">
                    <!-- muestra un listado de columnas de forma de tarjetas-->

                    <table class="table table-hover table-sm">
                        <thead>
                            <tr>
                                <th>ID Administrador</th>
                                <th>ID Productos</th>
                                <th>ID PROVEEDOR</th>


                            </tr>
                        </thead>
                        <tbody>
                        <?php $__currentLoopData = $ventas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>

                                <td><?php echo e($c->id); ?></td>

                                <td><?php echo e($c->id); ?></td>
                                <td> <?php echo e($c->id); ?></td>


                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>


        </div>
       
    </div>  
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\Proyecto_Laravel_pendiente\resources\views/ventas/llenarreporte.blade.php ENDPATH**/ ?>