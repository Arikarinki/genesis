<?php $__env->startSection('contenido'); ?>
<style>
    html,
    body {
        background-color: #2A2A2E;
        color: #636b6f;
        font-family: 'Nunito', sans-serif;
        font-weight: 2100;
        height: 100vh;
        margin: 10;
    }
</style>
<div class="container">
    <div class="row">
        <div class="col-md-12">
            <div class="card">
                <!-- muestra un listado de columnas de forma de tarjetas-->
                <div class="card-header">
                    Generar Reporte

                </div>
                <div class="card-body">
                    <form action="<?php echo e(route('ventas.guardar')); ?>" method="POST">
                        <?php echo csrf_field(); ?>

                        <div class="form-group">
                            <label for="">Id Usuario</label>
                            <input type="text" name="iduser" value="" maxlength="9" onKeypress="if (event.keyCode < 45 || event.keyCode > 57) event.returnValue = false;">
                        </div>
                        <div class="form-group">
                            <label for="">Id Productos</label>
                            <input type="text" name="idprod" value="" maxlength="9" onKeypress="if (event.keyCode < 45 || event.keyCode > 57) event.returnValue = false;">
                        </div>
                        <div class="form-group">
                            <label for="">Id Proveedor</label>
                            <input type="text" name="idprov" value="" maxlength="9" onKeypress="if (event.keyCode < 45 || event.keyCode > 57) event.returnValue = false;">
                        </div>

                

                        
                        <button type="submit" class="btn btn-primary">Guardar</button>
                        <a href="<?php echo e(route('inicio.name')); ?>" class="btn btn-danger">Cancelar</a>
                    </form>
                    <td>



                    
                    </td>
                    <div class="form-group">
                            <label for="exampleFormControlSelect1">Id Productos</label>
                            <select class="form-control" id="exampleFormControlSelect1">
                                <option></option>

                            </select>
                        </div>

                       
                        <div class="form-group">
                            <label for="exampleFormControlSelect1">Id Proveedor</label>
                           
                            <select class="form-control" id="exampleFormControlSelect1">
                            <?php $__currentLoopData = $proveedores; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $t): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($t->id); ?>"><?php echo e($t->id); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                          
                        </div>
                       
                </div>
            </div>
        </div>
    </div>


</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\DepositoGenesis\resources\views/ventas/llenarreporte.blade.php ENDPATH**/ ?>