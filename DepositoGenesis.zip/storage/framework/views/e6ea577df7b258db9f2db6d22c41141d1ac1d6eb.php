<?php $__env->startSection('contenido'); ?>
<style>
html, body {
                background-color:#2A2A2E;
                color: #636b6f;
                font-family: 'Nunito', sans-serif;
                font-weight: 2100;
                height: 100vh;
                margin: 10;
            }
            </style>
<div class="container">
    <div class="row">
        <div class="col-md-12">
            <div class="card">
                <!-- muestra un listado de columnas de forma de tarjetas-->
                <div class="card-header">
                    Agregar Proveedor

                </div>
                <div class="card-body">
                    <form action="<?php echo e(route('proveedor.guardarP')); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <div class="form-group>">
                            <label for="">Nombre</label>
                            <input type="text" class="form-control" name="nombre">
                        </div>
                        <div class="form-group">
                            <label for="">Dirección</label>
                            <input type="text" class="form-control" name="direccion">
                        </div>
                        <div class="form-group">
                            <label for="">Número</label>
                            <input type="" class="form-control" name="telefono">
                        </div>
                        <button type="submit" class="btn btn-primary">Guardar</button>
                        <a href="<?php echo e(route('proveedor.indexProveedor')); ?>" class="btn btn-danger">Cancelar</a>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\Proyecto_Laravel_pendiente\resources\views/proveedores/createP.blade.php ENDPATH**/ ?>