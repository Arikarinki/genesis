<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
    <title>Document</title>
</head>
<body>
<div class="container"><br>

      <div class="row">
       <div class="col-md-12">
        <div class="card"><!-- muestra un listado de columnas de forma de tarjetas-->                     
          <div class="card-header">
          Crear Producto
          </div>


          <div class="card-body">
                <form action="<?php echo e(route('productos.guardar')); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                    <div class="form-group>">
                    <label for="">Descripcion</label>
                  <input type="text" class="form-control" name="descripcion">
                </div>
                <div class="form-group">
                    <label for="">Precio</label>
                  <input type="text" class="form-control" name="precio">
              </div>  
              <button type="submit" class="btn btn-primary">Guardar</button>
              <a href="<?php echo e(route('productos.index')); ?>" class="btn btn-danger">Cancelar</a>
              </form>
        </div>
    </div>         
</div> 
</div> 
</div>  
</body>
</html><?php /**PATH /home/haniel/Descargas/Proyecto_Laravel/resources/views/productos/create.blade.php ENDPATH**/ ?>