<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <title>Document</title>
</head>

<body>

    <div class="container">
        <div class="card-header">
            <h2> Reporte De Productos</h2>

        </div>
        <div class="row">
            <div class="col-md-12">
                <div class="card">
                    <!-- muestra un listado de columnas de forma de tarjetas-->

                    <table class="table table-hover table-sm">
                        <thead>
                            <tr>
                                <th>Administrador</th>
                                <th>Productos</th>
                                <th>Precios</th>


                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $ventas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>

                                <td><?php echo e($p->name); ?></td>

                                <td><?php echo e($p->descripcion); ?></td>
                                <td><?php echo e($p->precio); ?> </td>


                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>


        </div>
        <div class="card-header">
            <h2>Proveedores</h2>

        </div>
        <div class="row">
            <div class="col-md-12">
                <div class="card">
                    <!-- muestra un listado de columnas de forma de tarjetas-->




                    <table class="table table-hover table-sm">
                        <thead>
                            <tr>
                                <th>Proveedor</th>
                                <th> Dirección</th>
                                <th>Telefono</th>


                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $ventas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>

                                <td><?php echo e($p->nombre); ?></td>

                                <td><?php echo e($p->direccion); ?></td>
                                <td><?php echo e($p->numero); ?> </td>


                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>

                </div>
            </div>
        </div>
    </div>
</body>

</html><?php /**PATH C:\laragon\www\Proyecto_Laravel_pendiente\resources\views/ventas/ventas.blade.php ENDPATH**/ ?>